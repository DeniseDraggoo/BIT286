<?php
$conn = mysqli_connect("localhost", "root", "", "duckie_land");
if(mysqli_connect_errno()) {
    echo "Failed to connect to mySQL: " . mysqli_connect_error();
    exit();
}




?>